const express = require('express')
const app= express();
const session = require('express-session')
const PORT = process.env.PORT || 3000;

app.set('view engine', 'ejs')
app.set('views', './ejsviews')
app.use(express.urlencoded({extended: false}));

app.use(session({
    secret: 'mysupersecretcode!!!***',
    saveUninitialized: false,
    resave:false,
    cookie: {maxAge:1000*60*60*24}

}))

const database = require('./database.js');
database.startDBandApp(app,PORT);

app.listen(PORT, () => {

    console.log(`Server is running at port ${PORT}`)
})

app.get('/' , (req, res) =>{

    res.render('UserHome')
})
app.get('/adminlogin' , (req, res) =>{

    res.render('AdminLogin')
})

app.post('/adminlogin' , (req, res) =>{

    const username= req.body.username
    const password= req.body.password

    if(username=='admin' && password=='password')
    {
        res.redirect('/editmap')
    }


})


app.get('/editmap' , (req, res) =>{

    app.locals.buildingCollection.find( {} ).toArray()

    .then(buildings=>{
        res.render('AdminHome',{buildings})    
    }) 
    .catch(error=>{
        console.log(`fuck`)
    })
    

})
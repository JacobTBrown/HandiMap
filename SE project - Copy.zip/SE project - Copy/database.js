const mongodb = require('mongodb')
const MongoClient = mongodb.MongoClient;
const ObjectID = mongodb.ObjectId; // type for _id field
const username = 'user';
const password= 'password';
const dbHost = 'localhost';
const dbPort = 27017;
const dbName = 'wsp'
const buildingCollectionName='buildings'

const dbURL = `mongodb://${username}:${password}@${dbHost}:${dbPort}?authSource=${dbName}`;

let dbclient;

function startDBandApp(app,PORT){
    MongoClient.connect(dbURL, {poolSize: 20, useNewUrlParser: true})
// pool size is the number of allowed simultaneous connections

    .then(client => {
            dbclient = client;
            app.locals.client=client;
            app.locals.wspDB=client.db(dbName)
            app.locals.buildingCollection = app.locals.wspDB.collection(buildingCollectionName);
            
    })
    .catch(err => {
        console.log('DB connection Error:', err)
            })

        }

process.on('SIGINT',()=>{
    dbclient.close();
    console.log('db connection closed by SIGINT')
process.exit();
})

module.exports.startDBandApp = startDBandApp;
module.exports.ObjectID=ObjectID;

